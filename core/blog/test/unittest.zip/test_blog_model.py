# from django.test import TestCase, SimpleTestCase
# from datetime import datetime

# from ..models import Post, Category
# from accounts.models.users import User
# from accounts.models.profiles import Profile



# class TestPostModel(TestCase):
#     def setUp(self):
#         self.user = User.objects.create_user(email="test@test.com", password="a/@1234567")
#         self.Profile = Profile.objects.create(
#             user=self.user,
#         first_name = "test_first_name",
#         last_name = "test_last_name",
#         descrption = "test descrions",
#     )
#     def test_create_post_with_valid_date(self):
#         post = Post.objects.create(
#             author = Profile
#             title = "test", 
#             content = "description",
#             status = True,
#             category = None, 
#             published_date = datetime.now()
#         )
#         self.assertEqual(post.title, 'test')





from django.test import TestCase
from datetime import datetime
from ..models import Post, Category
from accounts.models.users import User
from accounts.models.profiles import Profile

class TestPostModel(TestCase):
    def setUp(self):
        # ایجاد یوزر
        self.user = User.objects.create_user(
            email="test@test.com",
            password="a/@1234567"
        )
        # ایجاد پروفایل
        self.profile = Profile.objects.create(
            user=self.user,
            first_name="test_first_name",
            last_name="test_last_name",
            descrition="test description",
        )
        # ایجاد دسته‌بندی
        self.category = Category.objects.create(name="test category")

    def test_create_post_with_valid_data(self):
        post = Post.objects.create(
            author=self.profile,
            title="test",
            content="description",
            status=True,
            category=self.category,
            published_date=datetime.now()
        )
        self.assertEqual(post.title, "test")
        self.assertEqual(post.author, self.profile)
        self.assertEqual(post.category.name, "test category")
